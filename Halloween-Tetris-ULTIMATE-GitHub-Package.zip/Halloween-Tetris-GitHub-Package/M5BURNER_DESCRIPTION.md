# Halloween Tetris ULTIMATE - M5Burner Description

## Title: 🎃 Halloween Tetris ULTIMATE

## Short Description:
Halloween-themed Tetris with WiFi tools and universal TV remote. Features spooky colors, 50 IR codes, WiFi beacon spam, and ghost piece preview. The ultimate Halloween gaming device!

## Category: Games

## Detailed Description:
Transform your M5StickC Plus2 into the ultimate Halloween gaming device! This enhanced Tetris features Halloween-themed colors, "HAPPY HALLOWEEN!!" text, and spooky bordered gameplay. Includes WiFi scanner, 40 Halloween beacon networks, and a comprehensive universal TV remote with 50 power codes. Built-in IR emitter (GPIO19) works with most TV brands - no external hardware needed!

**Controls:** Joy UP=WiFi Scanner, Joy DOWN=TV Remote, L+R=Beacon Spam, M5=Game Start

## Credits:
Based on M5StickC Tetris • WiFi features inspired by Bruce Project • IR codes from TV-B-Gone by Mitch Altman & Limor Fried • IRremoteESP8266 library • Halloween enhancements and integration by community

## Hardware: M5StickC Plus2 + JoyC Hat

## Version: ULTIMATE-FINAL

## File Size: 1.04MB

## Tags: Halloween, Tetris, Games, WiFi, IR Remote, TV Remote, Spooky, October